/* FoodCosta Menu + Add to Cart */

// Official menu data is already loaded in index.html.
// Sort every category from low price to high price.
const data = (window.MENU_DATA || []).map(group => ({
  ...group,
  items: [...group.items].sort((a, b) => Number(a[1]) - Number(b[1]))
}));

const grid = document.getElementById("menuGrid");
const search = document.getElementById("search");
const quickCats = document.getElementById("quickCats");

const imageMap = {
  "Pizza":"https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=700&q=80",
  "Burgers":"https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=700&q=80",
  "Momos":"https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=700&q=80",
  "Noodles":"https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=700&q=80",
  "Chinese":"https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=700&q=80",
  "Chinese Corner":"https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=700&q=80",
  "Rice":"https://images.unsplash.com/photo-1563379091339-03246963d96c?auto=format&fit=crop&w=700&q=80",
  "Gang of Rice":"https://images.unsplash.com/photo-1563379091339-03246963d96c?auto=format&fit=crop&w=700&q=80",
  "Dal & Curries":"https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=700&q=80",
  "Evergreen Dal":"https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=700&q=80",
  "Sabji Ki Bahar":"https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=700&q=80",
  "Paneer Specials":"https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=700&q=80",
  "Paneer Ki Bahaar":"https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=700&q=80",
  "Sandwich":"https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=700&q=80",
  "Pasta":"https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=700&q=80",
  "French Fries":"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=80",
  "Shakes":"https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=700&q=80",
  "Mojito":"https://images.unsplash.com/photo-1551538827-9c037cb4f32a?auto=format&fit=crop&w=700&q=80",
  "Desserts":"https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=700&q=80",
  "Dessert":"https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=700&q=80",
  "Beverages":"https://images.unsplash.com/photo-1572449043416-55f4685c9bb7?auto=format&fit=crop&w=700&q=80",
  "Beverages • Hot & Ice Tea":"https://images.unsplash.com/photo-1572449043416-55f4685c9bb7?auto=format&fit=crop&w=700&q=80",
  "Soups":"https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=80",
  "default":"https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&w=700&q=80"
};

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}
function slug(s){return String(s).toLowerCase().replace(/[^a-z0-9]+/g,"-");}

// ---------------- CART ----------------
let cart = JSON.parse(localStorage.getItem("foodcosta_cart") || "[]");

function saveCart(){
  localStorage.setItem("foodcosta_cart", JSON.stringify(cart));
  updateCartUI();
}

function addToCart(name, price){
  const existing = cart.find(item => item.name === name && Number(item.price) === Number(price));
  if(existing){
    existing.qty += 1;
  } else {
    cart.push({name, price:Number(price), qty:1});
  }
  saveCart();
  showCartToast(`${name} added to cart`);
}

function changeQty(index, amount){
  if(!cart[index]) return;
  cart[index].qty += amount;
  if(cart[index].qty <= 0) cart.splice(index, 1);
  saveCart();
}

function removeFromCart(index){
  cart.splice(index, 1);
  saveCart();
}

function cartTotals(){
  const count = cart.reduce((sum,item)=>sum + item.qty, 0);
  const total = cart.reduce((sum,item)=>sum + item.price * item.qty, 0);
  return {count,total};
}

function createCartUI(){
  if(document.getElementById("cartButton")) return;

  const button = document.createElement("button");
  button.id = "cartButton";
  button.type = "button";
  button.innerHTML = `🛒 Cart <span id="cartCount">0</span>`;
  document.body.appendChild(button);

  const overlay = document.createElement("div");
  overlay.id = "cartOverlay";
  overlay.innerHTML = `
    <div class="cart-panel" role="dialog" aria-modal="true" aria-label="Shopping cart">
      <div class="cart-header">
        <div><h2>Your Cart</h2><span id="cartItemsLabel">0 items</span></div>
        <button id="closeCart" type="button" aria-label="Close cart">×</button>
      </div>
      <div id="cartItems" class="cart-items"></div>
      <div class="cart-footer">
        <div class="cart-total-row"><span>Total</span><strong id="cartTotal">₹0</strong></div>
        <button id="clearCart" class="clear-cart" type="button">Clear Cart</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  button.addEventListener("click",()=>overlay.classList.add("show"));
  overlay.addEventListener("click",e=>{if(e.target===overlay) overlay.classList.remove("show")});
  document.getElementById("closeCart").addEventListener("click",()=>overlay.classList.remove("show"));
  document.getElementById("clearCart").addEventListener("click",()=>{
    cart=[];
    saveCart();
  });

  const style = document.createElement("style");
  style.textContent = `
    #cartButton{position:fixed;right:18px;bottom:18px;z-index:9998;border:0;border-radius:999px;padding:13px 18px;background:#111;color:#fff;font-weight:700;font-size:15px;box-shadow:0 8px 24px rgba(0,0,0,.22);cursor:pointer}
    #cartButton span{display:inline-flex;min-width:22px;height:22px;align-items:center;justify-content:center;margin-left:6px;border-radius:50%;background:#fff;color:#111;font-size:12px}
    #cartOverlay{position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);display:flex;justify-content:flex-end;opacity:0;visibility:hidden;transition:.2s}
    #cartOverlay.show{opacity:1;visibility:visible}
    .cart-panel{width:min(430px,92vw);height:100%;background:#fff;display:flex;flex-direction:column;box-shadow:-10px 0 30px rgba(0,0,0,.18)}
    .cart-header{display:flex;justify-content:space-between;align-items:center;padding:20px;border-bottom:1px solid #eee}
    .cart-header h2{margin:0 0 3px;font-size:22px}.cart-header span{font-size:13px;color:#777}
    #closeCart{border:0;background:#f2f2f2;width:38px;height:38px;border-radius:50%;font-size:26px;cursor:pointer}
    .cart-items{flex:1;overflow:auto;padding:14px 18px}
    .cart-row{display:grid;grid-template-columns:1fr auto;gap:12px;padding:14px 0;border-bottom:1px solid #eee}
    .cart-name{font-weight:700;font-size:15px;line-height:1.3}.cart-price{font-size:13px;color:#666;margin-top:4px}
    .cart-controls{display:flex;align-items:center;gap:8px}.cart-controls button{width:30px;height:30px;border:1px solid #ddd;border-radius:8px;background:#fafafa;cursor:pointer;font-size:18px}.cart-controls strong{min-width:20px;text-align:center}
    .cart-remove{border:0!important;background:transparent!important;color:#b00020!important;font-size:12px!important;width:auto!important}
    .cart-empty{text-align:center;color:#777;padding:60px 15px}.cart-footer{padding:18px;border-top:1px solid #eee;background:#fff}
    .cart-total-row{display:flex;justify-content:space-between;font-size:18px;margin-bottom:12px}.cart-total-row strong{font-size:21px}
    .clear-cart{width:100%;padding:11px;border:1px solid #ddd;background:#fff;border-radius:10px;cursor:pointer;font-weight:700}
    .add{cursor:pointer}.cart-toast{position:fixed;left:50%;bottom:85px;transform:translateX(-50%);z-index:10000;background:#111;color:#fff;padding:10px 16px;border-radius:10px;font-size:14px;box-shadow:0 5px 20px rgba(0,0,0,.2)}
    @media(max-width:600px){#cartButton{right:12px;bottom:12px}.cart-panel{width:94vw}}
  `;
  document.head.appendChild(style);
}

function updateCartUI(){
  const {count,total}=cartTotals();
  const countEl=document.getElementById("cartCount");
  const label=document.getElementById("cartItemsLabel");
  const totalEl=document.getElementById("cartTotal");
  const itemsEl=document.getElementById("cartItems");
  if(countEl) countEl.textContent=count;
  if(label) label.textContent=`${count} item${count===1?"":"s"}`;
  if(totalEl) totalEl.textContent=`₹${total}`;
  if(!itemsEl) return;

  if(!cart.length){
    itemsEl.innerHTML=`<div class="cart-empty">Your cart is empty.<br>Add some delicious food! 🍕</div>`;
    return;
  }

  itemsEl.innerHTML=cart.map((item,index)=>`
    <div class="cart-row">
      <div>
        <div class="cart-name">${escapeHtml(item.name)}</div>
        <div class="cart-price">₹${item.price} × ${item.qty} = ₹${item.price*item.qty}</div>
      </div>
      <div class="cart-controls">
        <button type="button" data-cart-action="minus" data-index="${index}">−</button>
        <strong>${item.qty}</strong>
        <button type="button" data-cart-action="plus" data-index="${index}">+</button>
        <button type="button" class="cart-remove" data-cart-action="remove" data-index="${index}">Remove</button>
      </div>
    </div>`).join("");

  itemsEl.querySelectorAll("[data-cart-action]").forEach(btn=>{
    btn.addEventListener("click",()=>{
      const index=Number(btn.dataset.index);
      const action=btn.dataset.cartAction;
      if(action==="plus") changeQty(index,1);
      if(action==="minus") changeQty(index,-1);
      if(action==="remove") removeFromCart(index);
    });
  });
}

function showCartToast(message){
  const old=document.querySelector(".cart-toast");
  if(old) old.remove();
  const toast=document.createElement("div");
  toast.className="cart-toast";
  toast.textContent="✓ "+message;
  document.body.appendChild(toast);
  setTimeout(()=>toast.remove(),1400);
}

createCartUI();

// ---------------- MENU ----------------
const allCats = data.map(x => x.cat);
allCats.forEach(cat => {
  const b = document.createElement("button");
  b.textContent = cat;
  b.dataset.cat = cat;
  quickCats.appendChild(b);
});

quickCats.addEventListener("click", e => {
  const btn = e.target.closest("button");
  if(!btn) return;
  document.querySelectorAll(".category-strip button").forEach(x=>x.classList.remove("active"));
  btn.classList.add("active");
  render(btn.dataset.cat, search.value);
});

function render(selected="all", q=""){
  const term = q.trim().toLowerCase();
  const groups = data.filter(g => selected==="all" || g.cat===selected).map(g=>{
    const items = g.items.filter(([name])=>name.toLowerCase().includes(term));
    return {...g,items};
  }).filter(g=>g.items.length);

  if(!groups.length){
    grid.innerHTML = `<div class="empty">No dishes found. Try another search.</div>`;
    return;
  }

  grid.innerHTML = groups.map(g => `
    <section class="menu-category" id="${slug(g.cat)}">
      <div class="category-title"><h3>${escapeHtml(g.cat)}</h3><span class="line"></span><span class="count">${g.items.length} items</span></div>
      <div class="menu-grid">
      ${g.items.map(([name,price])=>`
        <article class="food-card">
          <img class="food-img" loading="lazy" src="${imageMap[g.cat]||imageMap.default}" alt="${escapeHtml(name)}">
          <div class="food-info">
            <div class="food-name">${escapeHtml(name)}</div>
            <div class="food-bottom"><span class="price">₹${price}</span><button class="add" data-name="${escapeHtml(name)}" data-price="${price}" aria-label="Add ${escapeHtml(name)}">Add to Cart</button></div>
          </div>
        </article>`).join("")}
      </div>
    </section>`).join("");

  grid.querySelectorAll(".add").forEach(btn=>{
    btn.addEventListener("click",()=>addToCart(btn.dataset.name,Number(btn.dataset.price)));
  });
}

search.addEventListener("input",()=>{
  const active=document.querySelector(".category-strip button.active");
  render(active ? active.dataset.cat : "all", search.value);
});

render();
updateCartUI();

const menuToggle=document.querySelector(".menu-toggle");
if(menuToggle){
  menuToggle.addEventListener("click",()=>{
    const nav=document.getElementById("navLinks");
    const open=nav.style.display==="flex";
    nav.style.display=open?"none":"flex";
    if(!open){nav.style.position="absolute";nav.style.top="70px";nav.style.left="0";nav.style.right="0";nav.style.background="#faf8f4";nav.style.padding="20px 5vw";nav.style.flexDirection="column";nav.style.borderBottom="1px solid #e9e1d8";}
  });
}
